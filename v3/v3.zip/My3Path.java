package ftp.v3;

import java.io.IOException;
import java.nio.file.LinkOption;
import java.nio.file.Path;

import org.apache.sshd.common.file.util.BasePath;
import org.apache.sshd.common.file.util.ImmutableList;

public class My3Path extends BasePath<My3Path, My3FileSystem>
{

  public My3Path(My3FileSystem fileSystem, String root, ImmutableList<String> names)
  {
    super(fileSystem, root, names);
    System.out.println("My3Path constructor");
    // TODO Auto-generated constructor stub
  }

  @Override
  public Path toRealPath(LinkOption... options) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3Path toRealPath(LinkOption... options)");
    return null;
  }

//  @Override
//  public File toFile()
//  {
//    // TODO Auto-generated method stub
//    return new File("z:/TEMP");
//  }
}
