package ftp.v3;

import java.io.IOException;
import java.net.URI;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.AccessMode;
import java.nio.file.CopyOption;
import java.nio.file.DirectoryStream;
import java.nio.file.DirectoryStream.Filter;
import java.nio.file.FileStore;
import java.nio.file.FileSystem;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.FileAttributeView;
import java.nio.file.spi.FileSystemProvider;
import java.util.Map;
import java.util.Set;

public class My3FileSystemProvider extends FileSystemProvider
{

  @Override
  public String getScheme()
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider getScheme()");
    return "aws";
  }

  @Override
  public FileSystem newFileSystem(URI uri, Map<String, ?> env) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider newFileSystem(); uri=" + uri);
    return new My3FileSystem(this);
  }

  @Override
  public FileSystem getFileSystem(URI uri)
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider getFileSystem(); uri=" + uri);
    return new My3FileSystem(this);
  }

  @Override
  public Path getPath(URI uri)
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider getPath(); uri=" + uri + " ; uri.getSchemeSpecificPart()=" + uri.getSchemeSpecificPart());
    return null;
  }

  @Override
  public SeekableByteChannel newByteChannel(Path path, Set<? extends OpenOption> options, FileAttribute<?>... attrs) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider newByteChannel()");
    return null;
  }

  @Override
  public DirectoryStream<Path> newDirectoryStream(Path dir, Filter<? super Path> filter) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider newDirectoryStream(); dir=" + dir + " ; dir instanceof My3Path?" + (dir instanceof My3Path) + " ; filter=" + filter);
    return new My3DirectoryStream();
  }

  @Override
  public void createDirectory(Path dir, FileAttribute<?>... attrs) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider createDirectory()");
  }

  @Override
  public void delete(Path path) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider delete()");
  }

  @Override
  public void copy(Path source, Path target, CopyOption... options) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider copy()");
  }

  @Override
  public void move(Path source, Path target, CopyOption... options) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider move()");
  }

  @Override
  public boolean isSameFile(Path path, Path path2) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider isSameFile()");
    return false;
  }

  @Override
  public boolean isHidden(Path path) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider isHidden()");
    return false;
  }

  @Override
  public FileStore getFileStore(Path path) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider getFileStore()");
    return null;
  }

  @Override
  public void checkAccess(Path path, AccessMode... modes) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider checkAccess(); path=" + path + " ; modes=" + modes);
  }

  @Override
  public <V extends FileAttributeView> V getFileAttributeView(Path path, Class<V> type, LinkOption... options)
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider getFileAttributeView()");
    return (V)new My3BasicFileAttributeView();
  }

  @Override
  public <A extends BasicFileAttributes> A readAttributes(Path path, Class<A> type, LinkOption... options) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider readAttributes(Path path, Class<A> type, LinkOption... options); path=" + path + " ; type=" + type + " ; options=" + options);
    return (A)new My3BasicFileAttributes();
//    return null;
  }

  @Override
  public Map<String, Object> readAttributes(Path path, String attributes, LinkOption... options) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider readAttributes(Path path, String attributes, LinkOption... options); path=" + path + " ;attributes=" + attributes + "; options=" + options);
//    Map<String, Object> map = new HashMap<>();
//    My3BasicFileAttributes attr = new My3BasicFileAttributes();
//    map.put("size", attr.size());
//    map.put("creationTime", attr.creationTime());
//    map.put("lastAccessTime", attr.lastAccessTime());
//    map.put("lastModifiedTime", attr.lastModifiedTime());
//    map.put("isDirectory", attr.isDirectory());
//    map.put("isRegularFile", attr.isRegularFile());
//    map.put("isSymbolicLink", attr.isSymbolicLink());
//    map.put("isOther", attr.isOther());
//    return map;
    return null;
  }

  @Override
  public void setAttribute(Path path, String attribute, Object value, LinkOption... options) throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystemProvider setAttribute()");
  }

}
