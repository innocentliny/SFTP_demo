package ftp.v3;

import java.io.IOException;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.sshd.common.file.util.BaseFileSystem;
import org.apache.sshd.common.file.util.ImmutableList;

public class My3FileSystem extends BaseFileSystem<My3Path>
{

  public My3FileSystem(My3FileSystemProvider fileSystemProvider)
  {
    super(fileSystemProvider);
    System.out.println("My3FileSystem constructor");
    // TODO Auto-generated constructor stub
  }

  @Override
  protected My3Path create(String root, ImmutableList<String> names)
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystem create(); root=" + root + " ; names=" + names);
    return new My3Path(this, root, names);
  }

  @Override
  public void close() throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystem close()");
  }

  @Override
  public boolean isOpen()
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystem isOpen()");
    return true;
  }

  @Override
  public Set<String> supportedFileAttributeViews()
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystem supportedFileAttributeViews()");
    return Collections.unmodifiableSet(new HashSet<String>(Arrays.asList("basic")));
  }

  @Override
  public UserPrincipalLookupService getUserPrincipalLookupService()
  {
    // TODO Auto-generated method stub
    System.out.println("My3FileSystem getUserPrincipalLookupService()");
    return null;
  }

}
