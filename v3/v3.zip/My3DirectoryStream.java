package ftp.v3;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class My3DirectoryStream implements DirectoryStream<Path>
{

  @Override
  public void close() throws IOException
  {
    // TODO Auto-generated method stub
    System.out.println("My3DirectoryStream close()");
  }

  @Override
  public Iterator<Path> iterator()
  {
    // TODO Auto-generated method stub
    System.out.println("My3DirectoryStream iterator()");
    List<Path> paths = new ArrayList<>();
//    paths.add(new My3Path());
    paths.add(Paths.get("z:/temp"));
//    paths.add(Paths.get("/2"));
    return paths.iterator();
  }

}
